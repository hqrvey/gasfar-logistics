// AUTH MIDDLEWARE: Runs BEFORE protected controllers to identify the caller.
import jwt from "jsonwebtoken"; // Check the signed login session token.
import User from "../models/User.js"; // Find the account in MongoDB.
import DriverProfile from "../models/DriverProfile.js"; // Check driver approval.

// Middleware receives (req, res, next). "next()" continues to the controller.
export async function requireAuth(req, res, next) {
  try {
    const token = req.cookies?.gasfar_session; // Cookie sent by the browser.
    if (!token) return res.status(401).json({ message: "Please log in." });

    // Verify that the token was signed by OUR backend and has not expired.
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.purpose !== "session") {
      return res.status(401).json({ message: "Invalid session." });
    }

    // Find the ACTUAL user in MongoDB (do not trust role claims from React).
    const user = await User.findById(payload.userId);
    if (!user || user.accountStatus !== "active") {
      return res.status(401).json({ message: "Session no longer valid." });
    }

    // A driver must be approved before using protected delivery endpoints.
    if (user.role === "driver") {
      const profile = await DriverProfile.findOne({ userId: user._id });
      if (!profile || profile.verificationStatus !== "approved") {
        return res.status(403).json({ message: "Driver account is not approved." });
      }
    }

    req.user = user; // All later controllers can now access req.user._id and role.
    next(); // Authorization succeeded: continue to allowRoles or controller.
  } catch {
    return res.status(401).json({ message: "Please log in again." });
  }
}

// Example: allowRoles("driver") blocks customers from accepting bookings.
export function allowRoles(...roles) {
  // Returns another middleware function, configured with allowed role names.
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: "You do not have permission." });
    }
    next(); // Role is permitted; run the booking controller.
  };
}
