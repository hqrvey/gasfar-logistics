// BOOKING ROUTES: A URL + HTTP method chooses which controller function runs.
// Example: React POST /api/bookings -> createBooking() -> Booking.create() -> MongoDB.
import express from "express"; // Express handles requests coming from React.
import { requireAuth, allowRoles } from "../middleware/authMiddleware.js"; // Check identity and role.
import {
  getBookings,
  getBooking,
  createBooking,
  acceptBooking,
  declineBooking,
  updateStatus,
  verifyDelivery,
  resendDeliveryPin,
  cancelBooking,
  updateDriverLocation,
} from "../controllers/bookingControllers.js"; // Actual database operations.

const router = express.Router(); // A mini-application for /api/bookings.

// ALL routes below require a valid login cookie. This sets req.user.
router.use(requireAuth);

// GET reads; POST creates; PATCH changes an existing booking.
router.get("/", allowRoles("customer", "driver", "admin"), getBookings); // List role-appropriate bookings.
router.post("/", allowRoles("customer"), createBooking); // Customer creates a pending booking.
router.get("/:id", allowRoles("customer", "driver", "admin"), getBooking); // Read one booking.
router.patch("/:id/accept", allowRoles("driver"), acceptBooking); // Driver accepts a request.
router.patch("/:id/decline", allowRoles("driver"), declineBooking); // Driver declines a request.
router.patch("/:id/status", allowRoles("driver"), updateStatus); // Move through 3 intermediate stages.
router.post("/:id/verify-delivery", allowRoles("driver"), verifyDelivery); // Correct PIN -> delivered.
router.post("/:id/resend-pin", allowRoles("driver"), resendDeliveryPin); // SMS recipient another PIN.
router.patch("/:id/cancel", allowRoles("customer", "driver"), cancelBooking); // Cancel if allowed.
router.patch("/:id/location", allowRoles("driver"), updateDriverLocation); // Save driver's GPS.

// server.js mounts this router at /api/bookings.
export default router;
