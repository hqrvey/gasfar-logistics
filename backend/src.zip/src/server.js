
/*
==========================================================
GASFAR BACKEND - SERVER.JS
==========================================================

WHAT IS THIS FILE?

This is the starting point of our Express backend.

Think of this file as the MAIN ENTRANCE to our REST API.

Its responsibilities are:

1. Load our environment variables from .env.
2. Create our Express server.
3. Set up middleware.
4. Connect our API routes.
5. Connect to MongoDB.
6. Start listening for requests from React.

IMPORTANT:

This file does NOT directly create bookings or register
customers.

Those operations are handled by CONTROLLERS.

The job of server.js is to connect everything together.

==========================================================
*/


// ========================================================
// STEP 1: IMPORT THE PACKAGES WE NEED
// ========================================================

// "import" allows us to use code from another file
// or an installed npm package.

// Express helps us create our REST API server.
import express from "express";

// dotenv reads the variables stored inside our .env file.
import dotenv from "dotenv";

// cors controls which browser websites can access our API.
import cors from "cors";

// cookie-parser allows us to read cookies sent by browsers.
import cookieParser from "cookie-parser";


// ========================================================
// STEP 2: IMPORT OUR OWN BACKEND FILES
// ========================================================

// Files beginning with "./" are local project files.

// connectDB is a function inside config/db.js.
// Its job is to connect our backend to MongoDB.

// The { } syntax means we are importing a named export.
import { connectDB } from "./config/db.js";

// These files contain our REST API routes.

// Authentication routes handle registration,
// login, logout, and verification.
import authRoutes from "./routes/authRoutes.js";

// Booking routes handle creating bookings,
// accepting deliveries, and updating statuses.
import bookingRoutes from "./routes/bookingRoutes.js";


// ========================================================
// STEP 3: IMPORT OUR MONGOOSE MODELS
// ========================================================

// A MODEL represents a MongoDB collection.

// For example:
// User model    -> users collection
// Booking model -> bookings collection

import User from "./models/User.js";

import DriverProfile from "./models/DriverProfile.js";

import VerificationCode from "./models/VerificationCode.js";

import Booking from "./models/Booking.js";


// ========================================================
// STEP 4: LOAD ENVIRONMENT VARIABLES
// ========================================================

// dotenv.config() reads the backend/.env file.

// After calling this function, we can access
// environment variables through process.env.

// For example:
//
// process.env.PORT
// process.env.MONGO_URI
// process.env.JWT_SECRET

dotenv.config();


// ========================================================
// STEP 5: CHECK REQUIRED ENVIRONMENT VARIABLES
// ========================================================

// These variables are required for our backend to work.

// We store their names inside an array.
// An array is a collection of values inside [ ].

const requiredVariables = [
  "MONGO_URI",
  "CLIENT_ORIGIN",
  "JWT_SECRET",
  "OTP_SECRET",
];

// "for...of" repeats the code below for each
// item inside our requiredVariables array.

// On each repetition, "key" contains one variable name.

for (const key of requiredVariables) {

  // process.env[key] reads the value from .env.
  //
  // Example:
  // If key = "MONGO_URI", this reads process.env.MONGO_URI.

  const value = process.env[key];

  // The ! operator means NOT.
  //
  // !value becomes true when the variable is missing
  // or contains an empty string.

  const isMissing = !value;

  // startsWith() checks the beginning of a string.
  //
  // This prevents us from accidentally using
  // placeholder values like REPLACE_WITH_YOUR_SECRET.
  //
  // || "" provides an empty string if value is missing.

  const isPlaceholder = (value || "").startsWith("REPLACE_");

  // || means OR.
  //
  // If either condition is true, there is a problem.

  if (isMissing || isPlaceholder) {

    // throw new Error() stops execution and reports
    // the problem.
    //
    // The backticks ` ` allow us to insert a variable
    // into a string using ${variable}.

    throw new Error(`Missing ${key} in backend/.env`);
  }
}


// ========================================================
// STEP 6: CHECK AUTHENTICATION SECRET LENGTHS
// ========================================================

// Authentication secrets help protect login sessions
// and verification codes.
//
// They should not be short or easy to guess.

// .length returns the number of characters in a string.

// < means "less than".

const jwtSecretTooShort = process.env.JWT_SECRET.length < 32;

const otpSecretTooShort = process.env.OTP_SECRET.length < 32;

// If either secret is too short, stop the server.

if (jwtSecretTooShort || otpSecretTooShort) {
  throw new Error(
    "JWT_SECRET and OTP_SECRET must each be at least 32 characters."
  );
}


// ========================================================
// STEP 7: CREATE OUR EXPRESS APPLICATION
// ========================================================

// express() creates our backend application.
//
// "const app" stores it in a variable named app.
//
// We will use app to register middleware,
// connect routes, and start the server.

const app = express();


// ========================================================
// STEP 8: CONFIGURE EXPRESS
// ========================================================

// This removes the X-Powered-By response header.
//
// It avoids unnecessarily advertising that
// our backend uses Express.

app.disable("x-powered-by");


// ========================================================
// STEP 9: SET UP CORS
// ========================================================

// CORS means Cross-Origin Resource Sharing.
//
// Our React frontend and Express backend usually
// run on different ports.
//
// Example:
//
// React:   http://localhost:5178
// Express: http://localhost:5001
//
// Browsers treat these as different origins.
//
// CORS lets us specify which browser origin
// is allowed to read responses from our backend.

// app.use() registers middleware.
//
// Middleware is code that runs while Express
// processes an incoming HTTP request.

app.use(
  cors({

    // Only allow our configured React origin.
    origin: process.env.CLIENT_ORIGIN,

    // Allow browsers to send authentication cookies.
    credentials: true,

  })
);


// ========================================================
// STEP 10: ALLOW EXPRESS TO READ JSON REQUESTS
// ========================================================

// React sends information to Express through HTTP.
//
// Example JSON from a booking form:
//
// {
//   "vehicleType": "motorcycle",
//   "deliveryType": "standard"
// }
//
// express.json() converts the incoming JSON into
// a JavaScript object.
//
// Controllers can then access it using req.body.
//
// limit: "100kb" limits the size of JSON request bodies.
// Uploaded files use a separate upload handler.

app.use(express.json({ limit: "100kb" }));


// ========================================================
// STEP 11: ALLOW EXPRESS TO READ COOKIES
// ========================================================

// Our login system uses an HTTP-only session cookie.
//
// When React makes an authenticated API request,
// the browser automatically includes that cookie.
//
// cookieParser() makes cookies available through
// the req.cookies object.
//
// Our authentication middleware can then read:
//
// req.cookies.gasfar_session

app.use(cookieParser());


// ========================================================
// STEP 12: CHECK THE REQUEST ORIGIN
// ========================================================

// This middleware adds an extra origin check
// for requests that change data.
//
// GET normally retrieves information.
// POST, PATCH, PUT, and DELETE normally change data.
//
// This is one additional browser-request protection.
// It is NOT a complete replacement for authentication,
// authorization, or CSRF protection.

app.use((req, res, next) => {

  // req = incoming HTTP request
  // res = HTTP response we will send back
  // next = function that passes control forward

  // req.get("origin") reads the Origin HTTP header.
  //
  // Some requests, such as direct API requests
  // from testing tools, may not contain this header.

  const origin = req.get("origin");

  // These HTTP methods normally do not change data.

  const safeMethods = ["GET", "HEAD", "OPTIONS"];

  // includes() checks whether req.method
  // appears inside the safeMethods array.

  const isSafeMethod = safeMethods.includes(req.method);

  // Check whether an Origin header was provided.

  const hasOrigin = Boolean(origin);

  // Compare the request origin with our allowed
  // frontend origin from backend/.env.

  const isAllowedOrigin = origin === process.env.CLIENT_ORIGIN;

  // Reject requests that:
  //
  // 1. Are not safe methods,
  // 2. Have an Origin header,
  // 3. Come from an unexpected origin.

  if (!isSafeMethod && hasOrigin && !isAllowedOrigin) {

    // HTTP 403 means Forbidden.
    //
    // .json() sends a JSON response to React.
    //
    // return stops this middleware function.

    return res.status(403).json({
      message: "Request origin not allowed.",
    });
  }

  // No problem was detected.
  //
  // next() tells Express to continue processing
  // this request using the next matching middleware
  // or route.

  next();
});


// ========================================================
// STEP 13: CONNECT OUR AUTHENTICATION ROUTES
// ========================================================

// app.use("/api/auth", authRoutes) means:
//
// Any request whose path begins with /api/auth
// is passed to authRoutes.js.
//
// Example:
//
// POST /api/auth/login
//
// Express first matches /api/auth.
// Then authRoutes.js matches /login.
// Finally, the login controller handles the request.

app.use("/api/auth", authRoutes);


// ========================================================
// STEP 14: CONNECT OUR BOOKING ROUTES
// ========================================================

// All booking-related REST API requests
// are handled by bookingRoutes.js.
//
// Example:
//
// POST /api/bookings
// PATCH /api/bookings/:id/accept
// PATCH /api/bookings/:id/status
//
// bookingRoutes.js determines which controller
// function should handle the request.

app.use("/api/bookings", bookingRoutes);


// ========================================================
// STEP 15: CREATE A HEALTH CHECK ENDPOINT
// ========================================================

// app.get() creates a route for HTTP GET requests.
//
// This route is useful for checking whether
// our Express server is running.
//
// Example URL:
// http://localhost:5001/api/health

app.get("/api/health", (req, res) => {

  // res.json() sends a JSON response.
  //
  // HTTP status 200 is used by default.

  res.json({
    status: "ok",
  });

});


// ========================================================
// STEP 16: HANDLE UNEXPECTED ERRORS
// ========================================================

// Express uses a special error-handling middleware
// with FOUR parameters:
//
// error = the error that happened
// req   = the incoming HTTP request
// res   = the outgoing HTTP response
// next  = Express's next middleware function
//
// Even though we don't use all four parameters,
// Express needs this four-parameter signature
// to recognize it as an error handler.
//
// This handler should come AFTER our routes.

app.use((error, req, res, next) => {

  // Some file-upload errors are produced by Multer.
  //
  // error.code identifies the specific upload problem.

  const uploadErrors = [
    "LIMIT_FILE_SIZE",
    "LIMIT_FILE_COUNT",
    "LIMIT_UNEXPECTED_FILE",
  ];

  // If the error is one of the recognized
  // upload errors, send HTTP 400.

  if (uploadErrors.includes(error.code)) {

    // HTTP 400 means Bad Request.

    return res.status(400).json({
      message:
        "Invalid or oversized file upload (maximum 8 MB each, 5 files).",
    });
  }

  // Express returns this error type when
  // the incoming JSON cannot be parsed.

  if (error.type === "entity.parse.failed") {

    return res.status(400).json({
      message: "Invalid JSON request.",
    });
  }

  // Some upload validation errors contain
  // a message beginning with "Only JPG".
  //
  // ?. is optional chaining.
  //
  // It prevents a crash if error.message
  // is missing or undefined.

  if (error.message?.startsWith("Only JPG")) {

    return res.status(400).json({
      message: error.message,
    });
  }

  // If none of the expected errors match,
  // we treat it as an unexpected server error.
  //
  // console.error() prints error information
  // in the backend terminal for debugging.

  console.error(error);

  // HTTP 500 means Internal Server Error.
  //
  // We send a generic message instead of exposing
  // sensitive internal error details to React.

  return res.status(500).json({
    message: "An unexpected server error occurred.",
  });

});


// ========================================================
// STEP 17: CONNECT TO MONGODB AND START EXPRESS
// ========================================================

// async means this function can perform asynchronous
// operations using await.
//
// Connecting to MongoDB takes time because
// the database may be on another server.

async function startServer() {

  // await tells JavaScript to wait for this
  // Promise to finish before continuing.
  //
  // connectDB() is defined inside config/db.js.
  //
  // It connects Mongoose to our MongoDB database.

  await connectDB();

  // Initialize our Mongoose models.
  //
  // Model.init() initializes the model and handles
  // index creation when automatic indexing is enabled.
  //
  // For example, unique indexes help prevent
  // duplicate usernames and booking codes.
  //
  // We do these one at a time because that is
  // easier to read than Promise.all().

  await User.init();

  await DriverProfile.init();

  await VerificationCode.init();

  await Booking.init();

  // Read the backend port from .env.
  //
  // The || operator provides a fallback value.
  //
  // If PORT is missing, use 5001.
  //
  // Number() converts the value into a number.

  const port = Number(process.env.PORT || 5001);

  // app.listen() starts the HTTP server.
  //
  // After this, Express can receive incoming
  // requests from React.
  //
  // The arrow function () => { } runs when
  // the server starts listening.

  app.listen(port, () => {

    console.log(
      `GASFAR API listening on http://localhost:${port}`
    );

  });
}


// ========================================================
// STEP 18: RUN THE STARTUP FUNCTION
// ========================================================

// Calling startServer() begins the process.
//
// Because startServer() is async, it returns a Promise.
//
// .catch() handles errors that cause the startup
// Promise to fail, such as a MongoDB connection failure.

startServer().catch((error) => {

  // Print the reason in the backend terminal.

  console.error(
    "Could not start server:",
    error.message
  );

  // process.exit(1) stops the Node.js program.
  //
  // 1 indicates that the program ended because
  // of an error.

  process.exit(1);

});


// ========================================================
// STEP 19: EXPORT OUR EXPRESS APPLICATION
// ========================================================

// export allows another JavaScript file to import app.
//
// This is useful for automated API tests.
//
// Exporting app does not start another server.
// The server has already been started above.

export { app };
