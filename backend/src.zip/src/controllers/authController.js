// AUTH CONTROLLER (registration/login): React calls /api/auth/... endpoints.
// Routes select a function, this controller validates input, models save MongoDB data,
// and res.json() sends only SAFE account information back to React.
// Admin approval / document access also live here to avoid unnecessary extra files.

// LEARN: Node built-in crypto provides random OTPs, irreversible HMAC codes, and safe comparisons.
import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
// LEARN: `promises as fs` renames Promise-based file functions so `await fs.unlink(...)` works.
import { promises as fs } from "node:fs";
// LEARN: Node path helper resolves secure file paths for admin-only driver documents.
import path from "node:path";
// LEARN: Mongoose also exposes `isValidObjectId()` for validating requested user IDs.
import mongoose from "mongoose";
// LEARN: bcrypt hashes stored passwords and compares login attempts without decrypting them.
import bcrypt from "bcryptjs";
// LEARN: JSON Web Tokens sign session cookies and temporary phone-verification proofs.
import jwt from "jsonwebtoken";
// LEARN: Import the Mongoose model for shared login accounts.
import User from "../models/User.js";
// LEARN: Driver-only approval and vehicle info stays in this separate collection.
import DriverProfile from "../models/DriverProfile.js";
// LEARN: Temporary OTP records are separate from the user collection.
import VerificationCode from "../models/VerificationCode.js";
// LEARN: The shared TextBee sender is a named export; never expose its API key to React.
import { sendSMS } from "../services/smsService.js";

// HELPER: Normalize Filipino mobile numbers so MongoDB/TextBee use one format.
// Accepted: 09171234567, 9171234567 or +639171234567.
// LEARN: Regular JavaScript helper to convert several PH mobile formats into +639... .
function normalizePhone(value) {
  // LEARN: Convert missing input to empty string, then replace ALL non-digits using regex /\D/g.
  let digits = String(value || "").replace(/\D/g, "");
  // LEARN: Remove country prefix using `.slice(2)`, keeping the national mobile number.
  if (digits.startsWith("63")) digits = digits.slice(2);
  // LEARN: Remove leading zero used by local phone format.
  if (digits.startsWith("0")) digits = digits.slice(1);
  // LEARN: A ternary returns normalized number when the regex matches, otherwise null.
  return /^9\d{9}$/.test(digits) ? `+63${digits}` : null;
}

// HELPER: Never send passwordHash, database-only data, or document filenames to React.
// LEARN: RESPONSE SHAPING: choose safe account fields for React, not the whole database document.
function userForClient(user) {
  return {
    // LEARN: Convert MongoDB ObjectId into a string for JSON and React comparisons.
    id: String(user._id),
    firstName: user.firstName,
    lastName: user.lastName,
    username: user.username,
    // LEARN: If email was optional/missing, send an empty string instead of undefined.
    email: user.email || "",
    phone: user.phone,
    role: user.role,
    accountStatus: user.accountStatus,
  };
}

// HELPER: Store an HMAC instead of storing OTP codes in plain text.
// LEARN: HMAC OTP with a server secret, keeping the plaintext verification code OUT of MongoDB.
function makeCodeHash(phone, code) {
  // LEARN: Use HMAC-SHA256 with OTP_SECRET from backend/.env.
  // Step 1: Create a cryptographic hash object using the secret in backend/.env.
  // Step 2: Add phone + code as the text to hash.
  // Step 3: Return the finished digest as hexadecimal text.
  // Dot chaining means "use the result of the previous method call".
  return createHmac("sha256", process.env.OTP_SECRET)
    .update(`${phone}:${code}`)
    .digest("hex");
}


// POST /api/auth/send-code: Request a phone verification SMS from TextBee.
// LEARN: Express route uses this exported function for POST /api/auth/send-code.
export async function sendCode(req, res, next) {
  try {
    // LEARN: Read phone sent by React and normalize it. `?.` prevents crashing on missing body.
    const phone = normalizePhone(req.body?.phone);
    if (!phone) return res.status(400).json({ message: "Enter a valid Philippine mobile number." });
    // LEARN: Before sending SMS, check if the phone is already registered in users.
    if (await User.exists({ phone })) return res.status(409).json({ message: "This phone number already has an account." });

    // Read an existing code document to enforce resend and attempt limits.
    // LEARN: Read old OTP attempt and resend counts from verificationcodes collection.
    const previous = await VerificationCode.findOne({ phone });
    // LEARN: Date.now gives an integer number of milliseconds since epoch.
    const now = Date.now();
    // LEARN: Milliseconds arithmetic enforces one-minute cooldown between OTP sends.
    if (previous && now - previous.lastSentAt.getTime() < 60000) {
      return res.status(429).json({ message: "Please wait 60 seconds before requesting another code." });
    }
    // LEARN: Limit resend requests; this is not a separate user account field.
    if (previous && previous.sends >= 5) {
      return res.status(429).json({ message: "Too many codes requested. Try again later." });
    }

    // Generate a random 6-digit code on the SERVER, not inside React.
    // LEARN: randomInt creates unpredictable six-digit OTP; upper bound is exclusive.
    const code = String(randomInt(100000, 1000000));
    try {
      // LEARN: TextBee request from server; template string inserts random code into SMS body.
      await sendSMS(phone, `GASFAR verification code: ${code}. It expires in 5 minutes.`);
    } catch (error) {
      console.error("Could not send registration OTP:", error.message);
      // LEARN: 502 Bad Gateway: SMS provider could not complete the request.
      return res.status(502).json({ message: "Unable to send verification SMS. Check the SMS service and try again." });
    }
    // Upsert means UPDATE an existing OTP record or INSERT a new one.
    // LEARN: Upsert the OTP record: find matching phone or create if missing.
    await VerificationCode.findOneAndUpdate({ phone }, {
      // LEARN: Save hashed code, NOT its plaintext value.
      codeHash: makeCodeHash(phone, code),
      // LEARN: Code expires five minutes after this request.
      expiresAt: new Date(now + 5 * 60 * 1000),
      lastSentAt: new Date(now),
      attempts: 0,
      // LEARN: Optional chaining plus fallback counts the first send as 1.
      sends: (previous?.sends || 0) + 1,
    // LEARN: upsert = insert if missing; new = return updated; validators = schema checks.
    }, { upsert: true, new: true, runValidators: true });

    res.json({ message: "Verification code sent." });
  } catch (error) { next(error); }
}

// POST /api/auth/verify-code: Check OTP and return a short-lived signup proof.
// LEARN: POST /api/auth/verify-code checks a submitted phone OTP.
export async function verifyCode(req, res, next) {
  try {
    const phone = normalizePhone(req.body?.phone);
    // LEARN: Force user-supplied OTP to text for regular-expression validation.
    const code = String(req.body?.code || "");
    // LEARN: Only 6 digits accepted; reject invalid phone or OTP before querying DB.
    if (!phone || !/^\d{6}$/.test(code)) return res.status(400).json({ message: "Invalid phone number or code." });
    // LEARN: Atomic query finds VALID, UNEXPIRED OTP and increments attempt count at once.
    const record = await VerificationCode.findOneAndUpdate(
      // FILTER (like SQL WHERE): correct phone, under 5 attempts, not expired.
      {
        phone,
        attempts: { $lt: 5 }, // $lt means strictly less than.
        expiresAt: { $gt: new Date() }, // $gt means strictly later than now.
      },
      // UPDATE (like SQL SET): even a wrong code counts as an attempt.
      { $inc: { attempts: 1 } },
      // OPTION: return the document AFTER incrementing, not before.
      { new: true }
    );
    if (!record) return res.status(400).json({ message: "Code expired or too many attempts. Request a new code." });
    // LEARN: Buffer creates bytes from a hex-encoded hash.
    const expected = Buffer.from(record.codeHash, "hex");
    // LEARN: Hash submitted code and convert it to bytes for safe comparison.
    const actual = Buffer.from(makeCodeHash(phone, code), "hex");
    // LEARN: Prevent predictable timing differences when checking the hash.
    if (!timingSafeEqual(expected, actual)) return res.status(400).json({ message: "Incorrect code." });

    // LEARN: Remove used OTP record so it cannot be verified twice.
    await VerificationCode.deleteOne({ _id: record._id });
    // A signed proof lets the register endpoint know phone verification happened.
    // LEARN: Sign a temporary proof that this phone passed OTP verification for registration.
    const verificationToken = jwt.sign({ purpose: "phone_signup", phone }, process.env.OTP_SECRET, { expiresIn: "15m" });
    res.json({ message: "Phone verified.", verificationToken });
  } catch (error) { next(error); }
}

// HELPER: Delete temporary uploaded documents if registration fails.
async function removeUploadedFiles(files = {}) {
  // Object.values(files) returns arrays of uploaded file objects.
  const arraysOfFiles = Object.values(files);

  // .flat() converts "an array of arrays" into ONE array.
  const individualFiles = arraysOfFiles.flat();

  // .map() transforms each file into a Promise for deleting its disk path.
  // .catch(() => {}) ignores missing-file errors while cleaning up.
  const deleteOperations = individualFiles.map((file) => {
    return fs.unlink(file.path).catch(() => {});
  });

  // Promise.all() waits until EVERY file-deletion Promise has settled.
  await Promise.all(deleteOperations);
}

// POST /api/auth/register: Save one User, plus DriverProfile for driver applicants.
// LEARN: POST /api/auth/register: create User, and optionally DriverProfile, after verification.
export async function register(req, res, next) {
  // LEARN: Track inserted User so we can clean it up if driver profile creation later fails.
  let createdUser = null;
  // LEARN: Track whether uploaded documents should be kept or deleted.
  let savedDriverProfile = false;
  try {
    // LEARN: OBJECT DESTRUCTURING: pull multiple named fields from req.body into local variables.
    const { firstName, lastName, username, email, password, confirmPassword, role, verificationToken, vehicleType, plateNumber } = req.body || {};
    const phone = normalizePhone(req.body?.phone);
    // LEARN: Normalize username so case/whitespace do not create duplicate-looking accounts.
    const cleanUsername = String(username || "").trim().toLowerCase();
    // LEARN: Normalize optional email before MongoDB unique-index check.
    const cleanEmail = String(email || "").trim().toLowerCase();
    const cleanFirst = String(firstName || "").trim();
    const cleanLast = String(lastName || "").trim();
    // LEARN: Keep the raw password only in temporary memory during validation and hashing.
    const passwordValue = String(password || "");

    // LEARN: No public admin signup: only customer and driver role values allowed here.
    if (!["customer", "driver"].includes(role)) return res.status(400).json({ message: "Only customer and driver signup is allowed." });
    // LEARN: Regex checks 8-30 permitted username characters; ^ and $ anchor whole string.
    if (!phone || !/^\w[\w.-]{7,29}$/.test(cleanUsername) || !cleanFirst || !cleanLast || cleanFirst.length > 80 || cleanLast.length > 80) {
      return res.status(400).json({ message: "Please enter valid personal information and a username of 8–30 characters." });
    }
    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return res.status(400).json({ message: "Invalid email address." });
    // LEARN: Count password bytes rather than characters for bcrypt input limits.
    if (passwordValue.length < 8 || Buffer.byteLength(passwordValue) > 72) return res.status(400).json({ message: "Password must be at least 8 characters." });
    // LEARN: Strict equality rejection catches mismatched repeated passwords.
    if (confirmPassword !== passwordValue) return res.status(400).json({ message: "Passwords do not match." });
    // LEARN: Registration requires accepted terms, supporting both string "true" and boolean true.
    if (req.body?.terms !== "true" && req.body?.terms !== true) return res.status(400).json({ message: "You must accept the terms and conditions." });

    try {
      // LEARN: Verify OTP proof signature and expiration using server secret.
      const proof = jwt.verify(String(verificationToken || ""), process.env.OTP_SECRET);
      // LEARN: Prevent using a token created for a different purpose or phone.
      if (proof.purpose !== "phone_signup" || proof.phone !== phone) throw new Error("Verification mismatch");
    } catch {
      return res.status(400).json({ message: "Phone verification expired. Please verify your phone again." });
    }

    // LEARN: Driver-only branch: create linked profile record; customer registration stops with just User.
    if (role === "driver") {
      const types = ["motorcycle", "sedan", "suv", "pickup", "l300"];
      // LEARN: Driver registration needs five named uploaded files.
      const requiredFiles = ["profilePhoto", "license", "or", "cr", "backplate"];
      // LEARN: Array.some returns true if ANY required upload is missing; Multer populates req.files.
      if (!types.includes(vehicleType) || !/^[A-Z0-9 -]{4,12}$/i.test(String(plateNumber || "").trim()) || requiredFiles.some((key) => !req.files?.[key]?.[0])) {
        return res.status(400).json({ message: "Vehicle type, plate number, and all five documents are required." });
      }
    }

    // LEARN: $or checks collisions across username, phone or optional email.
    if (await User.exists({ $or: [{ username: cleanUsername }, { phone }, ...(cleanEmail ? [{ email: cleanEmail }] : [])] })) {
      return res.status(409).json({ message: "Username, phone, or email is already registered." });
    }

    // Never save the plain password. bcrypt creates a salted one-way hash.
    // LEARN: bcrypt salted hash, work factor 12. The plaintext password is NEVER persisted.
    const passwordHash = await bcrypt.hash(passwordValue, 12);
    // User.create() validates User.js and inserts into MongoDB users collection.
    // LEARN: Mongoose validates User.js and INSERTS account into users collection.
    createdUser = await User.create({
      firstName: cleanFirst, lastName: cleanLast, username: cleanUsername, phone,
      // LEARN: Object SPREAD inserts email key only when an email exists.
      ...(cleanEmail ? { email: cleanEmail } : {}), passwordHash, role,
      // LEARN: Save the time OTP proof was accepted as a JavaScript Date.
      phoneVerifiedAt: new Date(),
    });

    if (role === "driver") {
      // Drivers also get a separate driverprofiles document, linked by userId.
      // LEARN: Insert a separate driverprofiles document; defaults verificationStatus=pending.
      await DriverProfile.create({
        // LEARN: Link profile to MongoDB primary key (_id) of just-created User.
        userId: createdUser._id,
        vehicle: { type: vehicleType, plateNumber },
        // LEARN: Convert [key,value] pairs from uploaded files into a documents object; map transforms file names.
        // Turn uploaded file records into { profilePhoto: "...", license: "...", ... }.
        // Object.fromEntries() builds an object from [key, value] pairs.
        documents: Object.fromEntries(
          ["profilePhoto", "license", "or", "cr", "backplate"].map((key) => {
            // Multer puts each file under req.files[fieldName], as an array.
            return [key, req.files[key][0].filename];
          })
        ),
      });
      // LEARN: Record that uploaded driver documents should not be deleted in finally.
      savedDriverProfile = true;
    }
    // LEARN: 201 Created; send only safe user object and a role-specific success message.
    res.status(201).json({ message: role === "driver" ? "Driver application submitted for approval." : "Account created. Please log in.", user: userForClient(createdUser) });
  } catch (error) {
    // LEARN: Compensating cleanup if driver profile insertion failed after User was created.
    if (createdUser) await User.deleteOne({ _id: createdUser._id }).catch(() => {});
    // LEARN: Unique-index collision may happen despite earlier User.exists check (concurrent signups).
    if (error.code === 11000) return res.status(409).json({ message: "Username, phone, or email is already registered." });
    next(error);
  // LEARN: `finally` always runs whether try succeeded or failed—needed for temporary files.
  } finally {
    // LEARN: Delete rejected/unused uploaded documents so disk storage does not grow.
    if (!savedDriverProfile) await removeUploadedFiles(req.files);
  }
}

// POST /api/auth/login: Verify identity and create an HTTP-only session cookie.
// LEARN: POST /api/auth/login: check credentials and issue a browser session cookie.
export async function login(req, res, next) {
  try {
    // LEARN: Login supports username OR phone OR email; normalize the supplied string.
    const identifier = String(req.body?.identifier || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (!identifier || !password || identifier.length > 254) return res.status(400).json({ message: "Enter your account and password." });
    const phone = normalizePhone(identifier);
    // LEARN: Build MongoDB alternatives for username and email.
    const clauses = [{ username: identifier }, { email: identifier }];
    // LEARN: `.push` appends a third possible lookup when input looks like a PH phone.
    if (phone) clauses.push({ phone });
    // passwordHash has select:false in User.js, so explicitly include it for login.
    // LEARN: Select matching account and include hidden password hash ONLY for comparison.
    const user = await User.findOne({ $or: clauses }).select("+passwordHash");
    // LEARN: A fixed dummy hash makes missing-account logins still perform bcrypt work.
    const dummyHash = "$2a$12$wHPruND06bqiTDzvmoG/HOrTpzmFeZ2ha8oOayvKynYNFNUTM9Ju2";
    // bcrypt.compare() checks a password against its hash; no plaintext lookup.
    // LEARN: Compare entered plaintext password to hash without decrypting the hash.
    const valid = await bcrypt.compare(password, user?.passwordHash || dummyHash);
    // LEARN: Use generic message to avoid disclosing which credentials were wrong.
    if (!user || !valid) return res.status(401).json({ message: "Invalid username, phone, email or password." });
    // LEARN: Suspend/disabled accounts cannot start a new session.
    if (user.accountStatus !== "active") return res.status(403).json({ message: "This account is not active." });
    if (user.role === "driver") {
      // LEARN: Check driver approval in driverprofiles, not User.verificationStatus.
      const profile = await DriverProfile.findOne({ userId: user._id });
      if (!profile || profile.verificationStatus !== "approved") {
        return res.status(403).json({ code: "DRIVER_PENDING", message: "Driver account is awaiting admin approval." });
      }
    }

    // LEARN: Only literal boolean true enables extended login duration.
    const remember = req.body?.remember === true;
    // LEARN: A ternary selects 7 days or 1 day, measured in milliseconds.
    const ageMs = remember ? 7 * 86400000 : 86400000;
    // LEARN: Create a signed JWT identifying this User and its session purpose.
    const token = jwt.sign({ purpose: "session", userId: String(user._id) }, process.env.JWT_SECRET, { expiresIn: remember ? "7d" : "1d" });
    // React cannot read an HttpOnly cookie; browser sends it on later API calls.
    // LEARN: Set HttpOnly cookie on response so browser auto-sends it on later REST requests.
    res.cookie("gasfar_session", token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: ageMs, path: "/" });
    res.json({ user: userForClient(user) });
  } catch (error) { next(error); }
}

// POST /api/auth/logout: Delete the browser login cookie.
// LEARN: Clear cookie in browser; this endpoint does not delete MongoDB user account.
export function logout(req, res) {
  // LEARN: Cookie name and relevant attributes should match how it was set.
  res.clearCookie("gasfar_session", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/" });
  res.json({ message: "Logged out." });
}

// GET /api/auth/me: Return the account attached by requireAuth middleware.
// LEARN: GET /api/auth/me: middleware already attached authenticated User as req.user.
export function me(req, res) {
  res.json({ user: userForClient(req.user) });
}

// ADMIN: Review driver profiles and verification documents.
// DriverProfile.verificationStatus belongs in driverprofiles, NOT users.
// LEARN: Admin lists driverprofiles documents, not all user accounts.
export async function listDriverApplications(req, res, next) {
  try {
    const applications = await DriverProfile.find()
      // LEARN: Mongoose populate loads selected fields from matching users documents (like a JOIN).
      .populate("userId", "firstName lastName username phone email")
      // LEARN: Sort newest first; -1 means descending.
      .sort({ createdAt: -1 });
    res.json({ applications });
  } catch (error) { next(error); }
}

// LEARN: Admin approves or rejects a driver profile after checking supplied ID/status.
export async function updateDriverApproval(req, res, next) {
  try {
    // LEARN: Destructure :id from URL parameters, e.g. /drivers/abc/approval.
    const { id } = req.params;
    // LEARN: Reject malformed ObjectId strings before DB lookup.
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: "Invalid driver ID." });
    // LEARN: Read requested approval from parsed JSON body.
    const status = req.body?.status;
    if (!["approved", "rejected"].includes(status)) return res.status(400).json({ message: "Status must be approved or rejected." });
    // LEARN: Update approval in driverprofiles using a matching userId.
    const profile = await DriverProfile.findOneAndUpdate(
      // LEARN: Return updated profile instead of the original document.
      { userId: id }, { verificationStatus: status, isOnline: false }, { new: true }
    );
    if (!profile) return res.status(404).json({ message: "Driver application not found." });
    res.json({ message: `Driver application ${status}.`, verificationStatus: profile.verificationStatus });
  } catch (error) { next(error); }
}

// LEARN: Admin-only endpoint to download a private verification file.
export async function getDriverDocument(req, res, next) {
  try {
    // LEARN: Read both route placeholders :id and :field from req.params.
    const { id, field } = req.params;
    if (!mongoose.isValidObjectId(id) || !["profilePhoto", "license", "or", "cr", "backplate"].includes(field)) {
      return res.status(400).json({ message: "Invalid document request." });
    }
    // LEARN: Query separate profile to find the allowed server-generated filename.
    const profile = await DriverProfile.findOne({ userId: id });
    // LEARN: Optional chaining and bracket notation select one approved document field safely.
    if (!profile?.documents?.[field]) return res.status(404).json({ message: "Document not found." });
    // Filenames are generated by the server and kept outside public directories.
    // LEARN: Send file bytes from a fixed private root, not a user-chosen path.
    res.sendFile(path.basename(profile.documents[field]), {
      // LEARN: Resolve directory where Multer saved verification documents.
      root: path.resolve("private-uploads"),
      headers: { "Content-Disposition": "attachment", "X-Content-Type-Options": "nosniff" },
    // LEARN: Only forward the sendFile error if HTTP headers have not already been sent.
    }, (error) => { if (error && !res.headersSent) next(error); });
  } catch (error) { next(error); }
}
