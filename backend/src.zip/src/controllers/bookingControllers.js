// BOOKING CONTROLLER: Every exported function below handles ONE REST API request.
// Flow: React calls bookingService -> Express route -> this controller -> Mongoose -> MongoDB.
// A controller responds with res.json(...); React receives that JSON in apiRequest().

// Node's built-in cryptography keeps our delivery PINs unpredictable and private.
import { createHmac, randomBytes, randomInt, timingSafeEqual } from "node:crypto";
// Import the Mongoose models used to read and write MongoDB documents.
import Booking from "../models/Booking.js";
import DriverProfile from "../models/DriverProfile.js";
// TextBee SMS stays on the BACKEND so the API key never reaches the browser.
import { sendSMS } from "../services/smsService.js";

// These statuses mean a driver currently has an active delivery.
// LEARN: An ARRAY lists the statuses considered active. `const` prevents reassigning the array variable; array items could still be modified.
const ACTIVE_STATUSES = ["accepted", "at_pickup", "picked_up", "arrived"];

// Each status has exactly one next stage. "delivered" needs a separate PIN check.
// LEARN: This OBJECT is a lookup table: NEXT_STATUS["accepted"] returns "at_pickup". It is not a MongoDB model.
const NEXT_STATUS = {
  accepted: "at_pickup",    // Driver arrived at the pickup location.
  at_pickup: "picked_up",  // Driver actually collected the package.
  picked_up: "arrived",    // Driver reached the drop-off location.
};

// For each stage, store a corresponding timestamp in MongoDB.
// LEARN: We map a requested status to the timestamp FIELD NAME to change in MongoDB.
const STATUS_DATE_FIELD = {
  at_pickup: "arrivedAtPickupAt",
  picked_up: "pickedUpAt",
  arrived: "arrivedAtDropoffAt",
};

// Store simple vehicle IDs in MongoDB; use friendly labels on React screens.
// LEARN: Store stable IDs in MongoDB; translate them to human-readable names for React screens.
const VEHICLE_LABELS = {
  motorcycle: "Motorcycle",
  sedan: "Sedan",
  suv: "SUV",
  pickup: "Pickup",
  l300: "L300",
};

// HELPER: Require an address and valid latitude/longitude for a location.
// LEARN: A HELPER is a regular JavaScript function used by controllers. `point` is its input ARGUMENT.
function validLocation(point) {
  // LEARN: `!` means NOT; `||` means OR. `typeof` checks the JavaScript value type. Early `return false` stops this helper.
  if (!point || typeof point.address !== "string") return false;
  // LEARN: `.trim()` removes surrounding spaces; `.length` counts remaining characters; `< 3` checks minimum length.
  if (point.address.trim().length < 3) return false;
  // LEARN: `Number.isFinite` rejects NaN, Infinity and non-number input. Latitude must be between -90 and 90.
  if (!Number.isFinite(point.lat) || point.lat < -90 || point.lat > 90) return false;
  // LEARN: Same validation for longitude, whose valid range is -180 to +180.
  if (!Number.isFinite(point.lng) || point.lng < -180 || point.lng > 180) return false;
  return true;
}

// HELPER: Turn common Philippine mobile formats into +639XXXXXXXXX.
// LEARN: Converts different PH phone inputs to the ONE database format; `value` comes from request data.
function normalizePhone(value) {
  // LEARN: String() converts to text; `|| ""` handles missing input; `/\D/g` matches ALL non-digits and `.replace` removes them.
  let digits = String(value || "").replace(/\D/g, ""); // Remove spaces, dashes and +.
  // LEARN: `.startsWith` detects the country prefix; `.slice(2)` removes the first two characters.
  if (digits.startsWith("63")) digits = digits.slice(2); // Remove country code.
  // LEARN: `.slice(1)` removes the leading zero of a local PH mobile number.
  if (digits.startsWith("0")) digits = digits.slice(1); // Remove leading zero.
  // LEARN: Regular expression: ^ starts text, 9 is required, \d{9} means nine digits, $ ends text; `.test` returns true/false.
  if (!/^9\d{9}$/.test(digits)) return null; // Must be 10 national digits.
  // LEARN: Backticks create a TEMPLATE STRING. `${digits}` inserts the variable into the text.
  return `+63${digits}`;
}

// HELPER: Return the booking fields our existing frontend expects.
// A MongoDB document can contain private fields; never return them by default.
// LEARN: Build a plain JavaScript response object for React. `viewer = null` is a DEFAULT PARAMETER.
function showBooking(booking, viewer = null) {
  // Pending requests must not expose the sender's/recipient's phone to every driver.
  // LEARN: `?.` OPTIONAL CHAINING avoids crashing when viewer is null. `&&` means AND: both conditions must be true.
  const hideContact = viewer?.role === "driver" && booking.status === "pending";
  // LEARN: Read an embedded field safely; undefined means no scheduled time is stored.
  const scheduledAt = booking.schedule?.scheduledAt;
  // LEARN: `let` allows reassignment after formatting; an empty string is our initial fallback.
  let localDate = "";
  let localTime = "";

  if (scheduledAt) {
    // Booking form uses Philippine local date/time (UTC+8, no DST).
    // LEARN: `new Date` creates a Date object. Adding 8 hours converts UTC into PH wall-clock time for the form.
    const philippinesTime = new Date(scheduledAt.getTime() + 8 * 60 * 60 * 1000);
    // LEARN: ISO strings begin YYYY-MM-DD; `.slice(0,10)` extracts the calendar date.
    localDate = philippinesTime.toISOString().slice(0, 10);
    // LEARN: Characters 11-15 of an ISO string represent HH:MM.
    localTime = philippinesTime.toISOString().slice(11, 16);
  }

  // Keep the public shape consistent for customer, driver, and history pages.
  return {
    id: booking.bookingCode, // Public ID used in /api/bookings/:id requests.
    status: booking.status, // Controls the five-stage progress indicator.
    pickup: booking.pickup,
    dropoff: booking.dropoff,
    customerName: booking.customerName,
    // LEARN: Mongoose ObjectIds are objects; String() turns them into text for a JSON-friendly frontend ID.
    customerId: String(booking.customerId),
    recipientName: booking.recipient?.name,
    // LEARN: TERNARY `condition ? yes : no`: hide the recipient phone from drivers viewing unaccepted jobs.
    recipientPhone: hideContact ? "" : booking.recipient?.phone,
    recipientUnit: booking.recipient?.unit,
    // LEARN: The same privacy rule applies to sender contact details.
    contactNumber: hideContact ? "" : booking.customerPhone,
    // LEARN: Bracket notation looks up the label by key; `||` falls back to the saved ID.
    vehicleType: VEHICLE_LABELS[booking.vehicleType] || booking.vehicleType,
    vehicleTypeId: booking.vehicleType,
    deliveryType: booking.deliveryType,
    // LEARN: If itemTypes is missing, give React an empty array instead of undefined.
    itemTypes: booking.packageDetails?.itemTypes || [],
    // LEARN: `.join(", ")` combines an array of item names into printable text. This is DISPLAY formatting.
    itemDetails: `${(booking.packageDetails?.itemTypes || []).join(", ")} · Qty: ${booking.packageDetails?.quantity || 1}`,
    quantity: booking.packageDetails?.quantity,
    itemWeight: booking.packageDetails?.itemWeight,
    handlingInstructions: booking.packageDetails?.handlingInstructions,
    notesToDriver: booking.packageDetails?.notesToDriver,
    scheduleType: booking.schedule?.type,
    scheduleDate: localDate,
    scheduleTime: localTime,
    // LEARN: Chained TERNARY chooses the human-friendly payment method label for the UI.
    paymentMethod: booking.payment?.method === "gcash" ? "GCash" : booking.payment?.method === "maya" ? "Maya" : "Cash",
    paymentSide: booking.payment?.payer,
    paymentStatus: booking.payment?.status,
    // LEARN: Divide centavos by 100 to show pesos; `.toLocaleString("en-PH")` adds locale-style separators.
    price: `₱${(booking.pricing.feeCentavos / 100).toLocaleString("en-PH")}`,
    feeCentavos: booking.pricing.feeCentavos, // Integer amount in centavos.
    driver: booking.driver?.name ? booking.driver : null,
    driverId: booking.driverId ? String(booking.driverId) : null,
    driverLocation: booking.driverLocation,
    // LEARN: `.getTime()` returns milliseconds since the Unix epoch, which React can compare for freshness.
    locationUpdatedAt: booking.locationUpdatedAt?.getTime() || null,
    // LEARN: `.map(String)` converts each ObjectId in the array to a string.
    declinedBy: (booking.declinedBy || []).map(String),
    // LEARN: `.map` transforms each event into a new object. `(event) => (...)` is an ARROW FUNCTION.
    statusHistory: (booking.statusHistory || []).map((event) => ({
      status: event.status,
      at: event.at,
    })),
    // LEARN: `toLocaleString` formats a Date for display; timezone option forces Asia/Manila.
    bookedAt: booking.createdAt?.toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Manila" }),
    completedAt: booking.deliveredAt?.toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Manila" }),
    cancelledAt: booking.cancelledAt?.toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Manila" }),
    cancelReason: booking.cancelReason,
    cancelledBy: booking.cancelledBy,
    // Never include deliveryPinHash, pinAttempts, or other secret PIN fields.
  };
}

// HELPER: Look up a booking by its public reference, not MongoDB's _id.
// LEARN: This returns a Mongoose QUERY (a thenable). Calling `await findBooking(code)` executes it.
function findBooking(bookingCode) {
  // LEARN: Shorthand `{ bookingCode }` means `{ bookingCode: bookingCode }`; MongoDB finds ONE matching record.
  return Booking.findOne({ bookingCode });
}

// HELPER: Authorization for GET /api/bookings/:id.
// LEARN: Checks an already-authenticated viewer against booking ownership; returns only true or false.
function canView(booking, user) {
  // LEARN: `===` is strict equality (also compares types). Admin accounts may read all bookings.
  if (user.role === "admin") return true;
  // LEARN: For customers, compare ObjectIds as STRINGS because separate ObjectId objects are not `===`.
  if (user.role === "customer") return String(booking.customerId) === String(user._id);
  // LEARN: Drivers may view individual bookings only when they are assigned to that booking.
  if (user.role === "driver") return String(booking.driverId) === String(user._id);
  return false;
}

// HELPER: The SERVER calculates the real route price, not the browser.
// LEARN: `async` allows network waiting with `await` and makes the function return a Promise.
async function calculateRoutePrice(pickup, dropoff) {
  // LEARN: `process.env` contains BACKEND environment variables; do not pass this API key to React.
  const apiKey = process.env.GEOAPIFY_API_KEY; // Secret from backend/.env.
  if (!apiKey) {
    // LEARN: `new Error(message)` creates a throwable error object; an HTTP status is attached below.
    const error = new Error("Set GEOAPIFY_API_KEY in backend/.env before creating bookings.");
    // LEARN: HTTP 503 = temporary service unavailable; replyError() converts this error into a response.
    error.status = 503;
    throw error;
  }

  // URLSearchParams safely encodes the requested locations and key.
  // LEARN: `URL` makes a URL object so you do not have to manually concatenate/escape every query parameter.
  const url = new URL("https://api.geoapify.com/v1/routing");
  // LEARN: Geoapify expects two GPS pairs joined by |. URLSearchParams safely encodes the query string.
  url.searchParams.set("waypoints", `${pickup.lat},${pickup.lng}|${dropoff.lat},${dropoff.lng}`);
  // LEARN: `mode=drive` requests a driving-road route rather than walking.
  url.searchParams.set("mode", "drive");
  // LEARN: Add backend Geoapify key to the request URL sent FROM Express.
  url.searchParams.set("apiKey", apiKey);

  // LEARN: `let response` declares a variable to fill after fetch completes.
  let response;
  try {
    // Give the external route service up to 12 seconds to respond.
    // LEARN: `fetch` makes a server-to-Geoapify HTTP request. `await` waits for its result.
    response = await fetch(url, { signal: AbortSignal.timeout(12000) });
  } catch {
    const error = new Error("Could not calculate delivery price. Try again.");
    error.status = 502;
    throw error;
  }

  // LEARN: HTTP responses have `.ok=true` only for 2xx statuses. Throw an error when routing fails.
  if (!response.ok) {
    const error = new Error("Routing service unavailable. Try again.");
    error.status = 502;
    throw error;
  }

  // LEARN: `.json()` parses the HTTP response BODY into a JavaScript object.
  const data = await response.json(); // Geoapify sends JSON, not a MongoDB document.
  // LEARN: `[0]` selects the first Geoapify route; `?.` avoids a crash if no route exists.
  const route = data.features?.[0]?.properties;
  // LEARN: Only trust numeric distance/time returned by the routing provider.
  if (!Number.isFinite(route?.distance) || !Number.isFinite(route?.time)) {
    const error = new Error("No driving route found for these locations.");
    error.status = 400;
    throw error;
  }

  // LEARN: Convert metres to kilometres, rounded to one decimal: e.g. 1234m -> 1.2km.
  const distanceKm = Math.round(route.distance / 100) / 10; // Metres -> kilometres.
  // LEARN: Convert seconds to minutes; Math.ceil rounds UP, Math.max enforces minimum 1.
  const durationMins = Math.max(1, Math.ceil(route.time / 60)); // Seconds -> minutes.
  // LEARN: Current demo price: ₱50 base + ₱12 per km. Multiply by 100 to store whole centavos.
  const feeCentavos = Math.round((50 + distanceKm * 12) * 100); // Current demo price rule.
  return { distanceKm, durationMins, feeCentavos };
}

// HELPER: Store only a secure HMAC of the PIN, never the plaintext PIN.
// LEARN: Secure hash helper: combine booking code and entered PIN, keyed by a secret only Express knows.
function hashPin(bookingCode, pin) {
  // LEARN: HMAC creates a one-way authentication digest; using OTP_SECRET prevents guessing the hash offline without the secret.
  return createHmac("sha256", process.env.OTP_SECRET)
    // LEARN: `.update` feeds text to the HMAC. Combining bookingCode limits a PIN hash to one booking.
    .update(`${bookingCode}:${pin}`)
    // LEARN: `.digest("hex")` outputs the finished hash as printable hexadecimal text.
    .digest("hex");
}

// HELPER: Only the backend sends recipient delivery PINs through TextBee.
// LEARN: Server-side SMS helper takes the Booking document and newly generated plaintext PIN.
async function sendDeliveryPin(booking, pin) {
  // LEARN: Only during local development, optionally log PINs for testing; never expose in production logs.
  if (process.env.NODE_ENV !== "production" && process.env.DEV_LOG_DELIVERY_PIN === "true") {
    console.log(`[LOCAL TEST] Delivery PIN for ${booking.bookingCode}: ${pin}`);
  }
  const text = `GASFAR delivery PIN for ${booking.bookingCode}: ${pin}. Give it only when your package arrives. Expires in 15 minutes.`;
  // LEARN: Use the shared TextBee service. `await` waits for its HTTP call, which may fail.
  await sendSMS(booking.recipient.phone, text);
}

// HELPER: Convert Mongoose/database failures into understandable HTTP responses.
// LEARN: Central BOOKING error formatter. It picks the appropriate HTTP status and JSON message.
function replyError(res, error) {
  // LEARN: MongoDB error 11000 = unique-index conflict, often another driver already has a job.
  if (error.code === 11000) {
    return res.status(409).json({ message: "Conflicting booking assignment or duplicate booking. Refresh and try again." });
  }
  // LEARN: Allow our own deliberately created errors to control the HTTP status.
  if (error.status) return res.status(error.status).json({ message: error.message });
  // LEARN: Mongoose ValidationError means saved values did not match Booking.js schema.
  if (error.name === "ValidationError") {
    // LEARN: Object.values extracts validation errors into an array; map gets each human-readable message.
    const messages = Object.values(error.errors).map((item) => item.message);
    return res.status(400).json({ message: messages.join("; ") });
  }
  console.error("Booking API:", error);
  return res.status(500).json({ message: "Unable to process booking. Try again." });
}

// POST /api/bookings: Customer submits the booking form.
// LEARN: `export` makes this request handler available to bookingRoutes.js; req is IN, res is OUT.
export async function createBooking(req, res) {
  try {
    // LEARN: `express.json()` filled req.body with React request JSON; empty object is fallback.
    const form = req.body || {}; // Express parsed React's JSON using express.json().

    // Check the form BEFORE writing any record to MongoDB.
    // LEARN: Reject missing/invalid GPS coordinates BEFORE trying MongoDB or Geoapify.
    if (!validLocation(form.pickup) || !validLocation(form.dropoff)) {
      return res.status(400).json({ message: "Valid pickup and drop-off locations are required." });
    }
    // LEARN: Object.keys returns allowed vehicle IDs as an array; `.includes()` checks membership.
    if (!Object.keys(VEHICLE_LABELS).includes(form.vehicleType) ||
        !["regular", "priority"].includes(form.deliveryType)) {
      return res.status(400).json({ message: "Select a valid vehicle and delivery type." });
    }

    // LEARN: Normalize recipient number before storing and sending the TextBee PIN.
    const recipientPhone = normalizePhone(form.recipientPhone);
    if (!String(form.recipientName || "").trim() || !recipientPhone) {
      return res.status(400).json({ message: "Recipient name and valid Philippine mobile number are required." });
    }

    // Require at least one package category and a sensible quantity.
    // LEARN: Array.isArray distinguishes arrays from text/objects; `.every` checks EVERY package category.
    const validItems = Array.isArray(form.itemTypes) && form.itemTypes.length > 0 &&
      form.itemTypes.every((item) => typeof item === "string" && item.length <= 50);
    // LEARN: Quantity must be a whole number within reasonable limits.
    const validQuantity = Number.isInteger(form.quantity) && form.quantity >= 1 && form.quantity <= 1000;
    if (!validItems || !validQuantity) {
      return res.status(400).json({ message: "Choose package items and a valid quantity." });
    }

    if (!["cash", "gcash", "maya"].includes(form.paymentMethod) ||
        // LEARN: Reject a payer value that is not listed in the schema.
        !["sender", "recipient"].includes(form.paymentSide)) {
      return res.status(400).json({ message: "Choose a payment method and payer." });
    }
    if (!["now", "scheduled"].includes(form.scheduleType)) {
      return res.status(400).json({ message: "Choose a delivery schedule." });
    }

    // LEARN: Immediate delivery has no schedule timestamp; scheduled deliveries fill this variable.
    let scheduledAt = null; // Immediate bookings have no scheduled datetime.
    if (form.scheduleType === "scheduled") {
      // LEARN: A regular expression checks YYYY-MM-DD shape; it does not yet validate that date exists.
      const validDate = /^\d{4}-\d{2}-\d{2}$/.test(form.scheduleDate || "");
      // LEARN: A regular expression checks HH:MM text shape before Date parsing.
      const validTime = /^\d{2}:\d{2}$/.test(form.scheduleTime || "");
      if (!validDate || !validTime) {
        return res.status(400).json({ message: "Choose a valid pickup date and time." });
      }
      // The form uses Philippine time. MongoDB stores the Date as UTC internally.
      // LEARN: Create an absolute timestamp using +08:00 for the Philippines.
      scheduledAt = new Date(`${form.scheduleDate}T${form.scheduleTime}:00+08:00`);
      // LEARN: Invalid Date produces NaN; dates must also be in the future.
      if (Number.isNaN(scheduledAt.getTime()) || scheduledAt.getTime() <= Date.now()) {
        return res.status(400).json({ message: "Choose a future pickup date and time." });
      }
    }

    // LEARN: Calls the helper above: backend, not browser, is the authority for price.
    const pricing = await calculateRoutePrice(form.pickup, form.dropoff);
    // LEARN: `new Date()` records the current timestamp; reuse it for a consistent event time.
    const now = new Date();
    // LEARN: Build a public order code from current milliseconds plus random hex bytes. _id is still generated separately.
    const bookingCode = `ORD-${Date.now()}-${randomBytes(3).toString("hex").toUpperCase()}`;

    // Booking.create() validates our Booking.js schema and INSERTS one document.
    // LEARN: MAIN INSERT: Mongoose checks Booking.js, then creates one document in MongoDB `bookings`.
    const booking = await Booking.create({
      bookingCode,
      // LEARN: Use the authenticated account from middleware. Never accept customerId directly from React.
      customerId: req.user._id, // Set by requireAuth; NEVER trust a customerId from React.
      // LEARN: A snapshot: template string combines authenticated first/last names.
      customerName: `${req.user.firstName} ${req.user.lastName}`,
      customerPhone: req.user.phone,
      // LEARN: Copy the validated pickup address/lat/lng embedded object into the booking.
      pickup: form.pickup,
      // LEARN: Copy the validated destination into the booking.
      dropoff: form.dropoff,
      recipient: {
        name: form.recipientName.trim(),
        // LEARN: The normalized phone becomes the recipient number to receive delivery SMS.
        phone: recipientPhone,
        unit: String(form.recipientUnit || "").trim(),
      },
      vehicleType: form.vehicleType,
      deliveryType: form.deliveryType,
      // LEARN: Object shorthand `scheduledAt` means `scheduledAt: scheduledAt`.
      schedule: { type: form.scheduleType, scheduledAt },
      packageDetails: {
        itemTypes: form.itemTypes,
        quantity: form.quantity,
        itemWeight: String(form.itemWeight || ""),
        // LEARN: Accept arrays only; otherwise use [] so the MongoDB field stays consistent.
        handlingInstructions: Array.isArray(form.handlingInstructions) ? form.handlingInstructions : [],
        notesToDriver: String(form.notesToDriver || ""),
      },
      // LEARN: Payment selection is recorded; this is NOT confirmation that actual money was collected.
      payment: { method: form.paymentMethod, payer: form.paymentSide, status: "unpaid" },
      pricing,
      // LEARN: Record the initial timeline event as an object inside an array.
      statusHistory: [{ status: "pending", at: now, by: req.user._id }],
    });

    // HTTP 201 means "created". React reads response.booking.id to show success.
    // LEARN: HTTP 201 Created + a SAFE booking JSON for the React success screen.
    return res.status(201).json({ booking: showBooking(booking, req.user) });
  } catch (error) {
    return replyError(res, error);
  }
}

// GET /api/bookings: Return only bookings the signed-in role is allowed to see.
// LEARN: GET handler: choose a MongoDB filter based on the signed-in role.
export async function getBookings(req, res) {
  try {
    // LEARN: `let` because different roles will assign different filter objects.
    let filter;

    if (req.user.role === "customer") {
      // Customer only sees bookings belonging to their own MongoDB _id.
      // LEARN: A WHERE condition restricting customers to their own bookings.
      filter = { customerId: req.user._id };
    } else if (req.user.role === "admin") {
      // Admin sees all application bookings (not old tutorial demo records).
      // LEARN: MongoDB `$exists:true` includes newer bookings that have a public bookingCode.
      filter = { bookingCode: { $exists: true } };
    } else {
      // Find the actual driver's approved vehicle in driver_profiles.
      // LEARN: Lookup driver vehicle/approval data in the separate driverprofiles collection.
      const profile = await DriverProfile.findOne({ userId: req.user._id });
      // LEARN: `?.` handles missing driver profile or vehicle fields safely.
      const vehicleType = profile?.vehicle?.type;
      // LEARN: One hour from now: used as a dispatch window for scheduled jobs.
      const nextHour = new Date(Date.now() + 60 * 60 * 1000);

      // Include BOTH their assigned jobs and eligible, still-pending requests.
      // LEARN: The driver filter includes their assigned deliveries OR available, compatible pending requests.
      filter = {
        // LEARN: MongoDB `$or` means any of the listed conditions may match (like SQL OR).
        $or: [
          // LEARN: First $or branch includes jobs currently assigned to this driver.
          { driverId: req.user._id },
          {
            // LEARN: In the second branch, only display requests still waiting for a driver.
            status: "pending",
            // LEARN: Null driverId means nobody is currently assigned to this request.
            driverId: null,
            vehicleType,
            // LEARN: `$ne` means NOT EQUAL; do not re-show jobs declined by this driver.
            declinedBy: { $ne: req.user._id },
            $or: [
              { "schedule.type": "now" },
              // LEARN: `$lte` means less-than-or-equal. Dot notation searches an embedded field.
              { "schedule.scheduledAt": { $lte: nextHour } },
            ],
          },
        ],
      };
    }

    // find() READS documents; sort newest first; limit prevents huge responses.
    // LEARN: Read bookings matching the role filter, newest first, maximum 200 records.
    const bookings = await Booking.find(filter).sort({ createdAt: -1 }).limit(200);
    // Convert MongoDB documents into plain JSON shapes React already understands.
    // LEARN: Convert every Mongoose document to the JSON structure expected by React.
    const visibleBookings = bookings.map((booking) => showBooking(booking, req.user));
    return res.json({ bookings: visibleBookings });
  } catch (error) {
    return replyError(res, error);
  }
}

// GET /api/bookings/:id: Read ONE booking by its public bookingCode.
// LEARN: GET one booking: `req.params.id` is extracted from the :id segment of the URL.
export async function getBooking(req, res) {
  try {
    // LEARN: Query MongoDB by public bookingCode passed in the URL.
    const booking = await findBooking(req.params.id);
    if (!booking) return res.status(404).json({ message: "Booking not found." });
    // LEARN: A valid login alone is not enough; check booking ownership.
    if (!canView(booking, req.user)) {
      return res.status(403).json({ message: "You cannot view this booking." });
    }
    return res.json({ booking: showBooking(booking, req.user) });
  } catch (error) {
    return replyError(res, error);
  }
}

// PATCH /api/bookings/:id/accept: Driver claims ONE pending booking.
// LEARN: Driver accepts a pending job. This endpoint is protected by role middleware BEFORE it runs.
export async function acceptBooking(req, res) {
  try {
    const profile = await DriverProfile.findOne({ userId: req.user._id });
    // LEARN: Checking only role=driver is not enough: the profile must be admin-approved.
    if (!profile || profile.verificationStatus !== "approved") {
      return res.status(403).json({ message: "Driver verification required." });
    }

    // A driver should not accept a new job while another is active.
    // LEARN: `.exists()` efficiently tests whether a matching active delivery exists.
    const busy = await Booking.exists({ driverId: req.user._id, status: { $in: ACTIVE_STATUSES } });
    if (busy) return res.status(409).json({ message: "Finish your current delivery before accepting another." });

    const now = new Date();
    const nextHour = new Date(Date.now() + 60 * 60 * 1000);
    // IMPORTANT: findOneAndUpdate() checks and changes ONE document atomically.
    // Matching status:"pending" prevents two drivers accepting the same booking.
    // LEARN: Atomic find+modify: MongoDB checks conditions AND assigns this job in one operation.
    const booking = await Booking.findOneAndUpdate(
      {
        // LEARN: Only update the specific booking from the requested URL.
        bookingCode: req.params.id,
        status: "pending",
        driverId: null,
        // LEARN: Only allow a driver with a matching vehicle category.
        vehicleType: profile.vehicle.type,
        declinedBy: { $ne: req.user._id },
        $or: [
          { "schedule.type": "now" },
          { "schedule.scheduledAt": { $lte: nextHour } },
        ],
      },
      {
        // LEARN: MongoDB `$set` replaces just the named fields, unlike replacing the whole document.
        $set: {
          driverId: req.user._id,
          // LEARN: First tracked delivery step begins on acceptance.
          status: "accepted",
          acceptedAt: now,
          driver: {
            name: `${req.user.firstName} ${req.user.lastName}`,
            phone: req.user.phone,
            plate: profile.vehicle.plateNumber,
            vehicleType: VEHICLE_LABELS[profile.vehicle.type],
          },
        },
        // LEARN: Append the acceptance event without replacing earlier history.
        $push: { statusHistory: { status: "accepted", at: now, by: req.user._id } },
      },
      // LEARN: `new:true` returns the updated document; `runValidators:true` runs schema checks on update fields.
      { new: true, runValidators: true } // Return the UPDATED document.
    );

    if (!booking) {
      return res.status(409).json({ message: "Booking unavailable, already accepted, or vehicle type does not match." });
    }
    return res.json({ booking: showBooking(booking, req.user) });
  } catch (error) {
    // A unique MongoDB index provides a second safeguard against two active jobs.
    return replyError(res, error);
  }
}

// PATCH /api/bookings/:id/decline: Hide a request from this driver only.
// LEARN: Declining does NOT cancel the customer booking: it only hides the request from that driver.
export async function declineBooking(req, res) {
  try {
    // $addToSet avoids repeating the driver's ID in declinedBy.
    // LEARN: Only assigned driver with active status can update location; no full document needed.
    const result = await Booking.updateOne(
      { bookingCode: req.params.id, status: "pending", driverId: null },
      // LEARN: `$addToSet` adds to an array only if the value is not already present.
      { $addToSet: { declinedBy: req.user._id } }
    );
    // LEARN: `matchedCount===0` means the condition matched no booking, perhaps already accepted.
    if (!result.matchedCount) {
      return res.status(409).json({ message: "This booking is no longer available." });
    }
    return res.json({ message: "Booking declined." });
  } catch (error) {
    return replyError(res, error);
  }
}

// PATCH /api/bookings/:id/status: Advance ONE delivery stage.
// LEARN: Driver advances one approved delivery stage through the REST API.
export async function updateStatus(req, res) {
  try {
    // LEARN: Read posted JSON status from React, e.g. {"status":"at_pickup"}.
    const requestedStatus = req.body?.status; // Example: "at_pickup".
    // Find which PREVIOUS status leads to the requested one.
    // LEARN: Search the lookup table for which CURRENT status allows the REQUESTED next status.
    const previousStatus = Object.keys(NEXT_STATUS).find(
      // LEARN: Arrow function returns true for the first matching predecessor. `.find` returns it or undefined.
      (status) => NEXT_STATUS[status] === requestedStatus
    );

    // No skipping and no "delivered" without a successful PIN.
    if (!previousStatus) {
      return res.status(400).json({ message: "Use the next delivery stage. Delivered requires PIN verification." });
    }

    const now = new Date();
    // LEARN: Get the MongoDB timestamp field name dynamically from the map above.
    const dateField = STATUS_DATE_FIELD[requestedStatus];
    // LEARN: COMPUTED PROPERTY `[dateField]` uses variable text as the object key.
    const newValues = { status: requestedStatus, [dateField]: now };
    // LEARN: Only the arrival-at-dropoff status will generate an SMS PIN.
    let pin = null;

    // When arriving at drop-off, prepare the recipient's 4-digit PIN.
    if (requestedStatus === "arrived") {
      // LEARN: Generate a random four-digit code. randomInt upper bound is exclusive.
      pin = String(randomInt(1000, 10000));
      // LEARN: Store one-way digest instead of saving plaintext PIN in the booking.
      newValues.deliveryPinHash = hashPin(req.params.id, pin);
      // LEARN: Expiration timestamp = current time + 15 minutes.
      newValues.pinExpiresAt = new Date(now.getTime() + 15 * 60 * 1000);
      newValues.pinAttempts = 0;
      newValues.pinSends = 1;
      newValues.pinLastSentAt = now;
    }

    // Check driverId and PREVIOUS status together: no one may skip stages.
    const booking = await Booking.findOneAndUpdate(
      // LEARN: Filter uses public ID, logged-in driver, AND exact prior stage; prevents skipping.
      { bookingCode: req.params.id, driverId: req.user._id, status: previousStatus },
      {
        $set: newValues,
        // LEARN: Append one immutable timeline event for the newly reached stage.
        $push: { statusHistory: { status: requestedStatus, at: now, by: req.user._id } },
      },
      { new: true, runValidators: true }
    );

    if (!booking) {
      return res.status(409).json({ message: "Booking is not assigned to you or this stage is no longer available." });
    }

    // LEARN: Track whether TextBee reported success when issuing delivery PIN.
    let smsSent = true;
    if (pin) {
      // The stage is saved even if the SMS gateway is temporarily offline.
      // The driver can then use the "Resend PIN" action.
      try {
        // LEARN: Send SMS AFTER the database stage update; if SMS fails, stage remains arrived.
        await sendDeliveryPin(booking, pin);
      } catch (error) {
        smsSent = false;
        console.error("Delivery PIN SMS error:", error.message);
      }
    }

    // LEARN: Ternary gives React a helpful message if TextBee could not send the first code.
    const message = pin && !smsSent
      ? "Arrived at drop-off. SMS failed; try Resend PIN."
      : "Delivery stage updated.";
    return res.json({ booking: showBooking(booking, req.user), smsSent, message });
  } catch (error) {
    return replyError(res, error);
  }
}

// POST /api/bookings/:id/resend-pin: Issue a NEW PIN for the recipient.
// LEARN: Administer cooldown, send limit and regenerated PIN for the arrived stage.
export async function resendDeliveryPin(req, res) {
  try {
    const now = new Date();
    // LEARN: Calculate a threshold: last send must be at least 60 seconds ago.
    const oneMinuteAgo = new Date(now.getTime() - 60 * 1000);
    const pin = String(randomInt(1000, 10000));

    // Enforce 60-second cooldown + at most four sends using one atomic update.
    const booking = await Booking.findOneAndUpdate(
      {
        bookingCode: req.params.id,
        driverId: req.user._id,
        status: "arrived",
        // LEARN: `$lt` means strictly LESS THAN. Stop after four sends.
        pinSends: { $lt: 4 },
        // LEARN: Resend only if last send is at or before the one-minute cutoff.
        pinLastSentAt: { $lte: oneMinuteAgo },
      },
      {
        $set: {
          deliveryPinHash: hashPin(req.params.id, pin),
          pinExpiresAt: new Date(now.getTime() + 15 * 60 * 1000),
          pinAttempts: 0,
          pinLastSentAt: now,
        },
        // LEARN: MongoDB atomically increments a counter by one.
        $inc: { pinSends: 1 },
      },
      { new: true }
    );

    if (!booking) {
      return res.status(429).json({ message: "PIN can't be resent yet, or the send limit has been reached." });
    }
    try {
      await sendDeliveryPin(booking, pin);
    } catch (error) {
      console.error("Resend PIN error:", error.message);
      return res.status(502).json({ message: "TextBee could not send the PIN. Try again later." });
    }
    return res.json({ message: "A new delivery PIN was sent to the recipient." });
  } catch (error) {
    return replyError(res, error);
  }
}

// POST /api/bookings/:id/verify-delivery: Recipient PIN completes the delivery.
// LEARN: Delivered status is NOT a generic status update; it requires recipient PIN.
export async function verifyDelivery(req, res) {
  try {
    // LEARN: Convert client input to text and fall back to empty string.
    const pin = String(req.body?.pin || "");
    // LEARN: Require exactly four digits, no letters or spaces.
    if (!/^\d{4}$/.test(pin)) {
      return res.status(400).json({ message: "Enter the 4-digit recipient PIN." });
    }

    // Atomically increase attempts BEFORE verifying the PIN.
    const booking = await Booking.findOneAndUpdate(
      {
        bookingCode: req.params.id,
        driverId: req.user._id,
        status: "arrived",
        // LEARN: `$gt` means greater-than; only accept PINs that expire in the future.
        pinExpiresAt: { $gt: new Date() },
        // LEARN: Reject after the allowed number of PIN attempts.
        pinAttempts: { $lt: 5 },
      },
      // LEARN: Increment attempt counter BEFORE checking the entered code.
      { $inc: { pinAttempts: 1 } },
      { new: true }
    // LEARN: `.select("+...")` explicitly includes schema fields marked select:false; needed only here.
    ).select("+deliveryPinHash +pinExpiresAt +pinAttempts");

    if (!booking) {
      return res.status(409).json({ message: "PIN expired, too many attempts, or delivery is not ready. Request a new PIN." });
    }

    // timingSafeEqual avoids revealing PIN information through timing differences.
    // LEARN: Convert stored hex hash to bytes. Buffer is Node.js binary-data type.
    const expected = Buffer.from(booking.deliveryPinHash || "", "hex");
    // LEARN: Hash ENTERED PIN with the same method, then convert it to bytes.
    const actual = Buffer.from(hashPin(booking.bookingCode, pin), "hex");
    // LEARN: Only compare equal-size Buffers; timingSafeEqual reduces timing side channels.
    const correct = expected.length === actual.length && timingSafeEqual(expected, actual);
    if (!correct) return res.status(400).json({ message: "Incorrect delivery PIN." });

    const now = new Date();
    // LEARN: Another guarded atomic update completes only if booking is STILL at drop-off.
    const completed = await Booking.findOneAndUpdate(
      { _id: booking._id, status: "arrived", driverId: req.user._id },
      {
        $set: { status: "delivered", deliveredAt: now, driverLocation: null, locationUpdatedAt: null },
        // LEARN: `$unset` deletes temporary PIN fields so old codes cannot be reused.
        $unset: { deliveryPinHash: "", pinExpiresAt: "", pinAttempts: "", pinSends: "", pinLastSentAt: "" },
        $push: { statusHistory: { status: "delivered", at: now, by: req.user._id } },
      },
      { new: true }
    );

    // LEARN: A race or repeated click may have already changed status; return HTTP 409 Conflict.
    if (!completed) return res.status(409).json({ message: "Delivery already completed or changed." });
    return res.json({ booking: showBooking(completed, req.user), message: "Delivery completed successfully." });
  } catch (error) {
    return replyError(res, error);
  }
}

// PATCH /api/bookings/:id/cancel: Keep the EXISTING cancellation behavior.
// Current version marks the booking cancelled, including driver cancellations
// before pickup. Changing this to "return to pending" is a separate policy change.
// LEARN: Existing policy cancels eligible customer/driver bookings; DOES NOT reassign a driver cancellation yet.
export async function cancelBooking(req, res) {
  try {
    // LEARN: Read trusted role from authentication middleware, not the request body.
    const role = req.user.role;
    // LEARN: Ternary selects which current states this role may cancel.
    const allowedStatuses = role === "customer" ? ["pending"] : ["accepted", "at_pickup"];
    // LEARN: Convert reason to text, trim spaces and limit length to 300 characters.
    const reason = String(req.body?.reason || "").trim().slice(0, 300);
    if (!reason) return res.status(400).json({ message: "Please select a cancellation reason." });

    // Only the booking customer or assigned driver can cancel their own job.
    // LEARN: Dynamic ownership conditions: customerId or driverId must match this session.
    const ownerFilter = role === "customer"
      ? { customerId: req.user._id }
      : { driverId: req.user._id };
    const now = new Date();

    const booking = await Booking.findOneAndUpdate(
      // LEARN: Object SPREAD `...ownerFilter` inserts ownership fields into one MongoDB WHERE filter.
      { bookingCode: req.params.id, ...ownerFilter, status: { $in: allowedStatuses } },
      {
        $set: {
          status: "cancelled", cancelledAt: now, cancelledBy: role,
          // LEARN: Clear GPS when cancelled; save the provided reason for history.
          cancelReason: reason, driverLocation: null, locationUpdatedAt: null,
        },
        $push: { statusHistory: { status: "cancelled", at: now, by: req.user._id } },
      },
      { new: true }
    );

    if (!booking) {
      return res.status(409).json({ message: "This booking can no longer be cancelled here. Contact support." });
    }
    return res.json({ booking: showBooking(booking, req.user) });
  } catch (error) {
    return replyError(res, error);
  }
}

// PATCH /api/bookings/:id/location: Save the assigned driver's GPS location.
// LEARN: Driver browser watches GPS; REST PATCH stores the latest position on its booking.
export async function updateDriverLocation(req, res) {
  try {
    // The browser supplies latitude/longitude numbers from watchPosition().
    // LEARN: Number(...) converts JSON coordinate input to a JavaScript number.
    const lat = Number(req.body?.lat);
    // LEARN: Same conversion for longitude; both must be validated.
    const lng = Number(req.body?.lng);
    // LEARN: Check finite numbers and legal latitude/longitude ranges to reject invalid GPS.
    const validCoordinates = Number.isFinite(lat) && Number.isFinite(lng) &&
      Math.abs(lat) <= 90 && Math.abs(lng) <= 180;
    if (!validCoordinates) return res.status(400).json({ message: "Invalid GPS coordinates." });

    const now = new Date();
    // Only the assigned driver may update GPS while the delivery is ACTIVE.
    const result = await Booking.updateOne(
      { bookingCode: req.params.id, driverId: req.user._id, status: { $in: ACTIVE_STATUSES } },
      // LEARN: Nested GPS object uses property shorthand `lat, lng`. LocationUpdatedAt marks freshness.
      { $set: { driverLocation: { lat, lng, address: "Driver GPS location" }, locationUpdatedAt: now } }
    );

    if (!result.matchedCount) {
      return res.status(409).json({ message: "No active assigned booking to update." });
    }
    return res.json({ message: "Location updated." });
  } catch (error) {
    return replyError(res, error);
  }
}
